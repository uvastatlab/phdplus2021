# some analysis of Albemarle county homes data

library(tidyverse)
library(scales)
library(plotly)

# load data
URL <- "https://github.com/uvastatlab/phdplus2021/raw/main/data/homes.rds"
homes <- readRDS(url(URL))


# median home values by hsdistrict
medians <- homes %>% 
  group_by(hsdistrict) %>% 
  summarise(n = comma(n()), 
            median_value = dollar(median(totalvalue)))
medians

# number of homes built by hsdistrict since 2000
homes_year_hs <- homes %>%  
  filter(yearbuilt >= 2000) %>% 
  group_by(hsdistrict) %>% 
  count(yearbuilt) 

p <- ggplot(homes_year_hs) +
  aes(x = yearbuilt, y = n, color = hsdistrict) +
  geom_line() +
  ylim(0, NA) +
  scale_color_discrete("High School\nDistrict") +
  labs(x = "Year Built", y = "Number Homes Built",
       title = "Number of Homes Built Since 2000")
ggplotly(p)


# extract values from data frame
medians$median_value[medians$hsdistrict == "Western Albemarle"]
medians$n[medians$hsdistrict == "Albemarle"]

