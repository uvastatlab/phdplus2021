# Intro to R workshop
# Spring 2021
# Jennifer Huck
# UVA Library

# This R Script will introduce you to scripts, installing and loading packages, 
# using tidyverse, keeping R up to date, viewing and changing your working 
# directory, importing data, evaluating data, and graphing Albemarle County real
# estate data. 

# Orientation to Scripts and Basic R operations---------------------------------

# Arithmetic
# Here, the plus sign is the 'operator'.  Operators are symbols that represent some sort of action.

# Run the code 1: Put the cursor anywhere in the line below, then Select the 'Run' 
# button near the top of the Script Editor
2+8/2
# Notice the console prints the code and the results. 

# Run the code 2: Put the cursor anywhere in the line below, then press 
# CTRL+Enter (Windows) or CMD+Enter (Mac)
(2+8)/2 
# You can also highlight some code to only run certain sections of the command 
# or script, then press CTRL+Enter/CMD+Enter to run.
# Highlight the part within the parentheses in the line above, then press 
# CTRL+Enter or CMD+Enter.

# Notice these comments.  You should use lots of comments when you write your 
# own scripts!  Do yourself a favor, and leave comments for the future version of 
# yourself. Preface comments with a hashtag: `#`.  You can also use hashtags to 
# "comment out" parts of your script when you are testing your code. 

# Let's make an object
# Create an object by taking this form:
# object <- value 
# Say in your head "object gets value"
# We are using the assignment operator: <- 
# Use <- instead of =

# Let's make some objects for housing square feet 
cottage <- 1000   # See how it gets saved in your Environment
mansion <- 10000  # aka "mansion gets ten thousand"

# Object names cannot start with a number, and they may not have spaces.
# Try your best to make object names explicit and short.
# Include spaces around your operators.  Spaces make your script easier to read.

# Tip: Keyboard shortcut: For assignment operator '<-' use ALT+- 
# That is, hold the ALT key, then press the - key (minus sign key)

# Mini-Your Turn: Below, type 'house', then press ALT+-, then type 6000, then run:


# Take advantage of RStudio autocomplete facility: 
# Mini-Your Turn: type the first 3 letters of cottage, press Tab or Enter, then 
# run:


Cottage <- 4000   # R is cAse sEnsiTive

cottage / 2       # We can do arithmetic with R objects
cottage + mansion # Simply prints to console, we aren't saving this as an object 
                  # in the Environment

cottage <- 2000   # We can reassign objects
cottage           # Verify by looking in the Environment or printing to console

two_homes <- cottage + mansion  # Save our arithmetic as a new object
# Tip: use snake_case by separating lowercase words with _.  
# it_is_easy_to_read

rm(Cottage)       # Remove an object
Cottage           # Now we get an error, because the object no longer exists

# Your turn #1------------------------------------------------------------------

# 1. A cottage costs $100.  Create an object labeled cottage_cost 
# (You do not need to include the dollar sign.)


# 2. How much does the cottage cost in Euros?  Use cottage_cost, 
# multiply by 0.82, and save as cottage_euros.


# Data Types--------------------------------------------------------------------

## scalar: holds one value at a time
# numeric
x <- 1
y <- 2.5
class(x)

# logical
m <- x > y  # Is x larger than y?
n <- x < y  # Is x smaller than y?
m
n
class(m)

# character (string)
d <- "cottage"
a <- "1" 
b <- "2.5" # Are a and b different from x and y?
x + y
a + b

## Vector - a sequence of data elements of the same basic type
# Numeric vector:
o <- c(1,2,5.3,6,-2,4)           

# Character vector:
p <- c("bedroom","bathroom","kitchen","living room","basement")

# Logical vector
q <- c(TRUE,TRUE,FALSE,TRUE,FALSE,TRUE)            

# indexing vectors - use brackets to reference elements in a vector
o[3]                       # pulls 3rd element
p[3:5]                     # pulls 3th-5th elements
q[c(1,3)]                  # pulls non-sequential elements

# matrix - a two-dimensional rectangular layout consisting of the same basic type
t <- matrix(
     1:12,                 # the data components
     nrow=4,               # number of rows
     ncol=3,               # number of columns
     byrow = FALSE)        # fill matrix by columns
t                          # print the matrix

# list - an ordered collection of objects 
w <- list(name="Jenn", mynumbers=o, mymatrix=t, age=5.3)

# data frame - similar to a matrix, except columns can be different data types 
# (i.e., can be numeric, string, logical, factor, etc.).  This is the data
# structure you are likely to use the most. 

# We will revisit data frames after we open up our Albemarle homes data. 

# Functions---------------------------------------------------------------------
# We have already used a few functions:
# c() function (combine or concatenate) to make a vector
# rm() to remove objects
# class() to determine what class an object is
# matrix() creates a matrix from the given set of values

# Functions are like verbs.  Objects are like nouns.  Functions allow you to do 
# things with your objects.

# Note that you usually put something inside the parenthesis next to the function 
# name.  They are called arguments. 
#Let's looks at our matrix function again:
mymatrix <- matrix(
  1:16,                 # the data components
  nrow=4,               # number of rows
  ncol=4,               # number of columns
  byrow = FALSE)

# You don't always put something inside the parentheses.
Sys.Date()

# Have questions about a function? Put a ? in front to get the R documentation:
?matrix
# Note the Usage section which shows you the "Arguments" the function takes, e.g.,
# matrix(data = NA, nrow = 1, ncol = 1, byrow = FALSE, dimnames = NULL)
# Note the labels that makes it easy for humans to understand

# You can run functions without argument labels, all in one row: 
myothermatix <- matrix(1:16, 4, 4, FALSE)        
myothermatix 
# But it's harder for humans to read, so you might as well use those labels! 

# Your turn #2------------------------------------------------------------------
# 1. Pull the last element from our numeric vector o (above).


# 2. Create a string vector consisting of 3 components. Remember the keyboard
# shortcut for the assignment <-  operator: ALT+-


#### Jump back to Intro to R website: "Using packages"

# Clear our workspace-----------------------------------------------------------

# Let's clear the objects we just made from our workspace since we don't need 
# them anymore.  Try the remove function (below), or click the Broom icon in the
# Environment console.
rm(list = ls())

# View and Change Your Working Directory----------------------------------------

# get your working directory
getwd()

# Set working the working directory to wherever you saved this script and
# albemarle_homes_2020.csv.  

# You can do this via point-and-click:
# Session...Set Working Directory...Choose Directory

# You can also set the working directory within the script or in the console.  
# Copy the file path that points to where you saved the workshop files.

# Windows example: Here is an example of a setting a Windows working directory:
# setwd("C:/Users/jah2ax/Box Sync/_R/workshops/intro_R") 
# Windows users: note the FORWARD slashes.  Windows default is a backslash.
# You have to change the backslashes to forward slashes for this to work in the 
# console. Also note the beginning drive letter, .e.g, "C:"

# Mac example: Here is an example of setting a Mac working directory:
# setwd("/users/jah2ax/Box Sync/_R/workshops/intro_to_R_Spring_2021")
# Mac users: your default is a backslash, which R likes, so that's good!
# There is no drive letter as with Windows.   

# Paste YOUR working directory file path here, between the quotes:
setwd("") 

# Verify the directory is correct
getwd() 

# Note that you can also see the working directory listed at the top of the Console

# Loading packages, reading conflicts------------------------------------------

# Let's load our first package: tidyverse 
library(tidyverse) 
# Remember, you only install a package once, but you must load it for every new R session. 

# Note the message that we see in the Console.  You should see what packages
# were loaded (ggplot2, tibble, etc.) and conflicts.  You should see 2 conflicts:
# x dplyr::filter() masks stats::filter()
# x dplyr::lag()    masks stats::lag()
# Those are okay! 

# If you see a Warning Message in red text below the conflicts, that is an error
# you need to fix.

# Note the message we got about masking.  You can read that as:
# The filter command in the dplyr package masks the filter command in the stats
# package. 

# Import homes data-------------------------------------------------------------

# You have several options for importing data.  let's try a few!

# 1. 
# Save the file to your working directory, and simply pull the file from 
# there. Since you already saved the file, and you just set your working 
# directory, just put the file name in quotes. 
homes <- read.csv("albemarle_homes_2020.csv")

# homes is now saved into memory as a data object.  Look for it in the 
# Environment pane. 

# 2. 
# read.csv is from the utils package, which comes with a standard installation 
# of R. There are other options.  Let's try the read_csv function from the readr 
# package that comes with tidyverse.
homes_readr <- read_csv("albemarle_homes_2020.csv")

# Let's compare homes and homes_readr
homes
homes_readr
# One of the biggest differences is the way that the objects print to the console.
# homes_readr is technically a tibble, and a tibble is simply the tidyverse's 
# version of a data frame.  Tibbles print nicely!

# 3. 
# Point and click: Look in the Environment window for the "Import Dataset: 
# From Text (base) or Text (readr)" button.  
# This method loses points because it is not very reproducible. 

# These are examples of data frames - tabular data made up of heterogenous data.
# Tabular in that you have a table of rows and columns.  Rows are generally 
# observations. Columns are generally variables.  Heterogenous in that the data 
# type of each column can vary: numeric, string, factor, etc.

# With our Homes data, we can see we have numeric data like Square Feet, and 
# strings like Condition. 


# Evaluate Data-----------------------------------------------------------------

# Get an overall view
homes        # print to console
View(homes)  # view spreadsheet-style data viewer
             # You can also click on "homes" in your Environment pane
class(homes) # what class of object this is

# Print out a few rows
head(homes)  # prints first 6 rows
tail(homes)  # prints last 6 rows 
# We got 6 rows back, but we only want 3.  What to do?
head(homes, n = 3)  # Add an argument to change your results
head(homes, 3)      # note that you get the same results as the above line since 
                    # arguments are in the right order

# Brief snippets
dim(homes)   # dimensions
nrow(homes)  # number of rows
ncol(homes)  # number of columns
names(homes) # column headings (variable names)

# Descriptive details
summary(homes) # Get a quick statistical summary of the dataset
               # Notice that some variables get a frequency count
               # while others get a six number summary (e.g., mean, median)
str(homes)     # View structure of the homes data
               # You can also view the structure by clicking on the little blue 
               # arrow next to the object in your Environment. 

#### A brief interlude to discuss factors---------------------------------------

# Notice in our summary() and str() print outs, we see a lot of character data. 
# Let's focus on `hsdistrict`.  There are only 3 high schools in Albemarle county 
# (plus one level for "Unassigned").  The high schools are fixed and known - 
# making it a categorical variable. Factors are a class of data, just like 
# numeric or character data.  

# Here is a quick way of importing all character (string) data as factors:
homes_factors <- read.csv("albemarle_homes_2020.csv", stringsAsFactors = TRUE)
str(homes_factors)

# Compare str(homes) and str(homes_factor).  The character data in 'homes' are 
# now Factors with Levels. Looking at 'hsidstrict' again, it shows "Factor w/ 4 
# levels". Also notice the numbers that follow. Factors are stored in memory as 
# integers, and the integers have associated "labels". 

# investigate factors for high school district
levels(homes_factors$hsdistrict)

# Check out tidyverse's forcats package for more details on how to manage factors.

#### Back to evaluating our data------------------------------------------------

# indexing dataframes - use $ to reference elements in a data frame
summary(homes$lotsize)  # Get a quick statistical summary of a single variable

# Save values by assigning objects
lot_size_mean <- mean(homes$lotsize)

# beware of missings!
summary(homes$bedroom)
mean(homes$bedroom)
mean(homes$bedroom, na.rm = TRUE)


# Your Turn #3------------------------------------------------------------------

# 1. Print the last 8 lines of 'homes'


# 2. Take advantage of Rstudio autocomplete by typing in summary(homes$) below 
# and pick a variable that you think looks interesting.


# 3. Save the median total value as an object.  


# 4. Fix these commands so they run correctly:
median(homes$Bedrooms, na.rm = TRUE)
Mean(homes$landvalue)

# 5. What is the range of years represented by Year Built? 
# Hint 1: `range()`. Hint 2: na.rm


#### Jump back to Intro to R website: "Organizing your project with R" 

# Projects----------------------------------------------------------------------

# Save this R script.  It should already be in a folder with 
# albemarle_homes_2020.csv.  Create a project by selecting the R Project icon 
# or File...New Project...Existing Directory...select the directory (folder) 
# where this R script is saved.

# Once you start working with a project, you will notice that opening a project
# will provide you with the same working directory, the command history, and 
# easy access to your files. 

# You also get a fresh environment, so you should reload libraries and data. 

# Re-load your libraries (~line 226, loads tidyverse)
# Re-load you data (~line 250, calls data from within your working directory)

# Use projects to keep input data, R scripts, history, analytic results, and
# figures together in the same directory!

#### Jump back to Intro to R website: "A basic R project file structure" 