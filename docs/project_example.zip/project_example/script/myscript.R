# Intro to R workshop - Project Example 
# Spring 2021
# Jennifer Huck
# UVA Library

# This R Script gives a quick example of how projects work, and how to organize 
# your files.  This R script is associated with an existing .RProj file. 
# Subfolders within the project directory were set up in advance. 

# Verify working directory------------------------------------------------------
getwd()
# Notice do not need setwd()

# Load pacakages----------------------------------------------------------------
library(tidyverse) 

# Import and view homes data----------------------------------------------------

# Import data with factors
homes <- read.csv("data/raw/albemarle_homes_2020.csv")
head(homes)

# Create Scottsville subset of data---------------------------------------------

# save Scottsville subset
crozet <- filter(homes, esdistrict == "Crozet") 

# view Scottsville subset
head(crozet)

# Export Scottsville subset as a csv                           
write.csv(crozet,"data/analysis/crozet.csv")

# Create a chart----------------------------------------------------------------

# bar chart of Scottsville homes total value 
ggplot(crozet, aes(x = totalvalue)) +
  geom_histogram()

# save figure
ggsave("output/figs/total_value.png") 
