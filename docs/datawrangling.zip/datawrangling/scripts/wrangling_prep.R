################################################
# Data Science Essentials in R: 
#    Data Exploration and Wrangling
#
# UVA Library Research Data Services
# February 17, 2021
# Michele Claibourn
# 
# Data Exploration and dplyr
# 1. Load library, read in data sets
# 2. count, filter, arrange
# 3. select, pipes
# 4. summarize, group_by
# Data Wrangling and preparation
# 5. Read in original data sources
# 6. Joining the data sets
# 7. More wrangling
# 8. Checking key variables
# 9. Mutate, if_else, factors
# 10. Remaining cleaning
# 11. Clean up and save
################################################


# .......................................
# 1. Load library, read in data sets ----

library(tidyverse)
library(lubridate)
homes <- read_csv("data/albemarle_homes_2020.csv")

names(homes)
glimpse(homes)


# Data Exploration ----
# .......................................
# 2. count, filter, arrange ----

count(homes, condition)
count(homes, esdistrict)

filter(homes, condition == "Excellent")
filter(homes, yearbuilt > 2011)
filter(homes, esdistrict == "Murray" & bedroom <= 2)
filter(homes, condition %in% c("Poor", "Substandard"))

arrange(homes, finsqft)
arrange(homes, desc(finsqft))


# YOUR TURN 1!
# a. Use count to see how many homes are in each value of usecode?


# b. Use filter to find the number of homes with condition rating of
#    substandard (condition) and with more than 3 bedrooms (bedroom)


# c. Use arrange to find the minimum of yearbuilt, 
#    and the maximum of year built




# .......................................
# 3. select, pipes ----

select(homes, totalvalue)
select(homes, lotsize:totalvalue)
select(homes, contains("year"))
select(homes, ends_with("district"))

# The totalvalue and lotsize for homes in the Murray school district 
#   arranged in descending order of lotsize

# without the pipe
arrange(
  select(
    filter(homes, esdistrict == "Murray"), 
    totalvalue, lotsize), 
  desc(lotsize))

# saving steps
tmp <- filter(homes, esdistrict == "Murray")
tmp <- select(tmp, totalvalue, lotsize)
arrange(tmp, desc(lotsize))

# with pipe
homes %>% 
  filter(esdistrict == "Murray") %>% 
  select(totalvalue, lotsize) %>% 
  arrange(desc(lotsize))


# YOUR TURN 2: 
# a. Use the pipe operator to find the homes with a condition rating 
#   of substandard (condition) and count how many are in each 
#   elementary school zone (esdistrict)




# .......................................
# 4. summarize, group_by ----

homes %>% 
  filter(yearbuilt > 0) %>% 
  summarize(oldest = min(yearbuilt), 
            largest = max(finsqft), 
            total = n())

homes %>% 
  filter(yearbuilt > 0) %>% 
  group_by(esdistrict) %>% 
  summarize(oldest = min(yearbuilt), 
            avgsqft = mean(finsqft), 
            number = n())


# YOUR TURN 3: 
# Use group_by and summarize to find the total number of homes,
#   the median lot size (lotsize), and the average total value 
#   (totalvalue) by the rating of the homes condition (condition)




# Data Wrangling ----
# .......................................
# 5. Read in original data sources ----
# setwd("../data_prep_materials")

card_raw <- read_tsv("data-raw/GIS_CardLevelData_new.txt")
parcel_raw <- read_tsv("data-raw/GIS_View_Redacted_ParcelInfo .txt")
other_raw <- read_tsv("data-raw/CityView_View_OtherParcelCharacteristics.txt")

names(card_raw)
glimpse(card_raw)

# Let's pick the variables we want by first creating a vector of variables,
#   and using that in a select function; then create a new variable
#   to identify the original file source for these data.

card_vars <- c("TMP", "CardNum", "YearBuilt", "YearRemodeled", 
          "UseCode", "Condition", "FinSqFt", "Cooling", "FP_Open", 
          "Bedroom", "FullBath", "HalfBath", "TotalRooms")

card <- card_raw %>% 
  select(all_of(card_vars)) %>% 
  mutate(source = "card")


# YOUR TURN 4
# a. Create two new datasets, called parcel and other, by selecting 
#   the chosen variables from the raw datasets and add a variable
#   called source to each, with source equal to "parcel" or 
#   to "other" as appropriate.

parcel_vars <- c("ParcelID", "Owner", "LotSize", "PropName", "LandValue", "LandUseValue", "ImprovementsValue", "TotalValue", "LastSalePrice", "LastSaleDate1", "Cards")


other_vars <- c("ParcelID", "ESDistrict", "MSDistrict", "HSDistrict" , "CensusTract")



# .......................................
# 6. Joining the data sets ----

# We know from the county webpage that we should be able to join these files by TMP in cards 
#   and Parcel ID in parcel and other. But let's check them. 

n_distinct(card$TMP) # multiple cards per parcel are possible
n_distinct(parcel$ParcelID) # should uniquely identify parcel
n_distinct(other$ParcelID) # should uniquely identify parcel

# Quickly checking on those duplicates in other
tmp <- other %>% 
  group_by(ParcelID) %>% 
  summarize(dups = n()) %>% 
  filter(dups > 1) 
other %>% filter(ParcelID %in% tmp$ParcelID)
# These won't cause a problem for our join

# Left-join parcel and other
parcel_other <- parcel %>% 
  left_join(other, by = "ParcelID")

# Note the addition of source.x and source.y; 
#  If two columns exist with the same name in both datasets, 
#  you'll get variable names like this denoting which dataset the 
#  variable comes from. For rows with no match, this can be helpful
#  in further understanding.

# remove source.y, rename source.x to source, and move it to the end
parcel_other <- parcel_other %>% 
  select(-source.y) %>% 
  select(everything(), "source" = "source.x")

# Full-join card to parce_other
homes_new <- card %>% 
  full_join(parcel_other, by = c("TMP" = "ParcelID"))
# Because the primary key name differed across these sources, 
#   we had to tell R what columns to join on. We could also have
#   renamed TMP to ParcelID before joining.

# Check the result of the merge by looking at the source.x and source.y 
#   variables. If missing, then no matching parcel was found.

homes_new %>% 
  filter(is.na(source.x)) %>% 
  tally() # shortcut for summarize(n())
# 9124 observations are only found in the parcel dataset
# most have 0 improvements (no buildings).

homes_new %>% 
  filter(is.na(source.y)) %>% 
  tally()
# 1 observation was in the card dataset only

# Let's filter these out (and remove source.x and source.y columns)
homes_new <- homes_new %>% 
  filter(!is.na(source.y) & !is.na(source.x)) %>% 
  select(-c(source.y, source.x))


# .......................................
# 7. More wrangling ----

# a. Make variable names lower case
str_to_lower(names(homes_new))
names(homes_new) <- str_to_lower(names(homes_new))
# also str_to_upper(), str_to_title() or str_to_sentence() functions

# b. reduce to residential homes
homes_new %>% 
  count(usecode) %>% 
  print(n = Inf)

res <- c("Duplex", "Single Family", "Single Family-Rental")
homes_new <- homes_new %>% 
  filter(usecode %in% res)

# c. fix misclassified variables

# mutate(across()): applies the same transformation to multiple columns
homes_new %>% 
  mutate(across(where(is.character), as.numeric))
# we don't want all of the characters to be numeric, though
# let's define some vectors instead...

numvar <- c("yearbuilt", "yearremodeled", "finsqft", 
            "bedroom", "fullbath", "halfbath", "totalrooms", 
            "landvalue", "landusevalue", "improvementsvalue", 
            "totalvalue", "lastsaleprice")

homes_new <- homes_new %>% 
  mutate(across(numvar, as.numeric))

# and one for factors...
facvar <- c("condition", "cooling", "esdistrict", "msdistrict", 
            "hsdistrict", "censustract")

homes_new <- homes_new %>% 
  mutate(across(facvar, as.factor))

# and convert sale date to date format... 
homes_new <- homes_new %>% 
  mutate(lastsaledate = as.Date(lastsaledate1, "%m/%d/%Y"))


# .......................................
# 8. Checking key variables ----

# a. totalvalue
summary(homes_new$totalvalue)

homes_new %>%  # check NAs
  filter(is.na(totalvalue)) %>% 
  select(yearbuilt, finsqft, lotsize, landvalue, improvementsvalue, totalvalue) %>% 
  print(n = Inf)

homes_new %>% # check 0s
  filter(totalvalue == 0) %>% 
  select(yearbuilt, finsqft, lotsize, landvalue, improvementsvalue, totalvalue) 
# these seem like bad data -- a property with square footage and/or land
#   should have some value... but as we can't use them, we'll remove them.

homes_new <- homes_new %>% 
  filter(!is.na(totalvalue) & totalvalue > 0)

# b. finsqft
summary(homes_new$finsqft) 

homes_new %>% # check NAs 
  filter(is.na(finsqft)) %>% 
  select(yearbuilt, finsqft, owner, lotsize, propname, improvementsvalue)
# some commercial, or condo-ish (remove below)

homes_new %>% # check 0s
  filter(finsqft == 0) %>% 
  select(yearbuilt, finsqft,  owner, lotsize, propname, improvementsvalue) %>% 
  arrange(desc(improvementsvalue)) %>% 
  print(n = Inf)
# outside of the first 3, these don't seem to have improvements valued 
#   highly enough to be a home (remove below)

# check the high end
homes_new %>% 
  filter(finsqft > 5000) %>% 
  select(yearbuilt, usecode, finsqft, totalrooms, owner, lotsize:totalvalue, cards) %>% 
  arrange(desc(finsqft)) %>% 
  View()
# some of these are not single family homes (some probably are -- Howie, Jaffray, etc.)
# limit this, e.g, < 10K

# remove rows with finsqft >= 10000, = 0, or NA
homes_new <- homes_new %>% 
  filter(!is.na(finsqft) & finsqft > 0 & finsqft < 10000)

# c. lotsize
summary(homes_new$lotsize)

homes_new %>% # check 0s
  filter(lotsize == 0) %>% 
  arrange(finsqft) %>% 
  View()
# almost certainly incorrect (given landvalue has positive values), ah well...

homes_new %>%  # check high end
  filter(lotsize > 250) %>% 
  arrange(desc(lotsize)) %>% 
  View()
# many farms (also golf course, school, ashlawn, etc.)
# ... many with multiple properties on one assessment

# remove records with 2 or more cards associated with parcel
homes_new <- homes_new %>% 
  filter(cards < 2)
# this needs more nunaced thinking, but in the interest of moving on...


# .......................................
# 9. Mutate, if_else, factors ----

# a. mutate/if_else: yearbuilt/age
# derive age of home
homes_new <- homes_new %>% 
  mutate(age = 2019 - yearbuilt)

summary(homes_new$age) 
# instead of dropping the missing obs, we can impute the value based off of other observations
# impute median value within census tract for missing
tract_age <- homes_new %>% 
  group_by(censustract) %>% 
  summarize(med_age = round(median(age, na.rm = TRUE)))

# join the med_age values back to our dataset
homes_new <- left_join(homes_new, tract_age, by = "censustract")

# then use an if_else function to fill in those that were missing
homes_new <- homes_new %>% 
  mutate(age = if_else(is.na(age), med_age, age))


# b. factors: condition
homes_new %>% 
  count(condition) 

# re-order levels of factor by our own defined order
cond_levels <- c("Substandard", "Poor", "Fair", "Average", "Good", "Excellent", "Unknown", "NULL") 

homes_new <- homes_new %>% 
  mutate(condition2 = fct_relevel(condition, cond_levels)) 

summary(homes_new$condition2)

# combine unknown and null into none and relevel: fct_collapse, fct_relevel
homes_new <- homes_new %>% 
  mutate(condition2 = fct_collapse(condition2,
                                   None = c("Unknown", "NULL")),
         condition2 = fct_relevel(condition2, "None", after = 0))

summary(homes_new$condition2)


# .......................................
# 10. Remaining cleaning ----
# run, but don't discuss

#   yearremodeled, cooling, fp_open, bedroom, fullbath,
#   halfbath, totalrooms, landvalue, landusevalue, improvementsvalue,
#   lastsaleprice, esdstrict, msdistrit, hsdistrict, censustract

# yearremodeled -> remodel indicator
summary(homes_new$yearremodeled) # NA not remodeled; not sure about 2 or 8
homes_new <- homes_new %>% 
  mutate(yearremodeled = if_else(yearremodeled %in% c(2,8), NA_real_, yearremodeled),
         remodel = if_else(!is.na(yearremodeled), 1, 0),)

# cooling
table(homes_new$cooling) # fix factor -- assume 00, M1, and NULL are no air
homes_new <- homes_new %>% 
  mutate(cooling = fct_collapse(cooling, 
                                "No Central Air" = c("00", "M1", "NULL")))

# fp_open (these are characters)
table(homes_new$fp_open) # make a binary indicator, 0 and Null are none
homes_new <- homes_new %>% 
  mutate(fp = if_else(fp_open %in% c("0", "NULL"), 0, 1))

# bedroom, fullbath, halfbath, totalrooms 
table(homes_new$bedroom) # 103 homes with no bedroom is a likely error
table(homes_new$fullbath) # 168 homes with no full bath is a likely error
table(homes_new$halfbath) # ok
table(homes_new$totalrooms) # 479 homes with no rooms is a likely error

# landvalue
summary(homes_new$landvalue) # no missing, some 0s
homes_new %>% filter(landvalue == 0) %>% count(lotsize) # 12 total, only one with 0 lotsize

# landusevalue
summary(homes_new$landusevalue) # no missing
homes_new <- homes_new %>% # create binary indicator for land use (land generates revenue)
  mutate(landuse = if_else(landusevalue > 0, 1, 0)) %>% 
  select(-landusevalue) # remove variable
table(homes_new$landuse)

# improvementsvalue
summary(homes_new$improvementsvalue) # no missing, some 0s

# create a tmp file with ImprovementsValue == 0, arrange the file by finsqft
tmp <- homes_new %>% 
  filter(improvementsvalue == 0) %>% 
  arrange(finsqft)
# several new buildings with common values (e.g., condo/th dev?)

# lastsaleprice
summary(homes_new$lastsaleprice)
tmp <- homes_new %>% 
  filter(lastsaleprice == 0) %>% 
  arrange(lastsaledate) 
# first ~ 700 records, last sale date is prior to year built 


# YOUR TURN 5:
# a. Find the proportion of homes remodeled in each school district 
# ... and sort the cities by this proportion


# b. Does average property value (improvementsvalue) appear related 
# ...to assessed condition (condition2)?


#..................................
# 11. Clean up and save ----
# remove a few additional variables -- these were for examining the data
homes_new <- homes_new %>% 
  select(-c(cardnum, fp_open, owner, propname, cards, med_age))

saveRDS(homes_new, file = "data/homes.Rds")


# compare to homes
diff_list <- mapply(setdiff, homes_new, homes)
names(diff_list[lengths(diff_list) != 0])

# differences are from conversions occurring in the csv file and 
# issues with dates; the new data is formatted more accurately
homes_new %>% 
  select(tmp, lastsaledate, lastsaledate1) %>% 
  glimpse()

homes %>% 
  select(tmp, lastsaledate, lastsaledate1) %>% 
  glimpse()
